package prototype;

public class Prestamo {
}
