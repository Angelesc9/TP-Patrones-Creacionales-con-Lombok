package builder;

public class Usuario {
}
