package factory;

public class Libro {
}
