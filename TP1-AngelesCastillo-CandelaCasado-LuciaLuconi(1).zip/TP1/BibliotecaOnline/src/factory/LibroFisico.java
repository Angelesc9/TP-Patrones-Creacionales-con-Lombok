package factory;

public class LibroFisico {
}
