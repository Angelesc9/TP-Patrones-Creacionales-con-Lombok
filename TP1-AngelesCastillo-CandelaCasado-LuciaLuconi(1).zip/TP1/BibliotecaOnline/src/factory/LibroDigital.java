package factory;

public class LibroDigital {
}
