package abstractfactory;

public class InterfazUI {
}
