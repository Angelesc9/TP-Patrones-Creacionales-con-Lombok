package abstractfactory;

public class UsuarioUI {
}
