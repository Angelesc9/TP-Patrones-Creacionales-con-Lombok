package abstractfactory;

public class MetodoEnvio {
}
