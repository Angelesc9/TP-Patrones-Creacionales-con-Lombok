package abstractfactory;

public class EnvioNormal {
}
