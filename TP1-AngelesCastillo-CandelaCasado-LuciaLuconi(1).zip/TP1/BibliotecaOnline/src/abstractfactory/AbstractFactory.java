package abstractfactory;

public class AbstractFactory {
}
