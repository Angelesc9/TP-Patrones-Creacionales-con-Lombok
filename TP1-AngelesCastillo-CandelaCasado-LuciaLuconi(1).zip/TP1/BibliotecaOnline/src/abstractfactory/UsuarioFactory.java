package abstractfactory;

public class UsuarioFactory {
}
