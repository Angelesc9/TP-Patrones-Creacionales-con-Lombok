package abstractfactory;

public class AdminFactory {
}
