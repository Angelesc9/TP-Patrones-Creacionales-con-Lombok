package abstractfactory;

public class AdminUI {
}
